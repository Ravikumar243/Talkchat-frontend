__turbopack_load_page_chunks__("/_error", [
  "static/chunks/9e883_next_dist_compiled_712bffdb._.js",
  "static/chunks/9e883_next_dist_shared_lib_8ad05970._.js",
  "static/chunks/9e883_next_dist_client_fe082e00._.js",
  "static/chunks/9e883_next_dist_91312c1c._.js",
  "static/chunks/9e883_next_error_43788141.js",
  "static/chunks/[next]_entry_page-loader_ts_b9ef54ef._.js",
  "static/chunks/9e883_react-dom_3d11c48e._.js",
  "static/chunks/9e883_bb6d2665._.js",
  "static/chunks/[root-of-the-server]__2b803f7d._.js",
  "static/chunks/frontend_pages__error_2da965e7._.js",
  "static/chunks/turbopack-frontend_pages__error_e0f67bf1._.js"
])
