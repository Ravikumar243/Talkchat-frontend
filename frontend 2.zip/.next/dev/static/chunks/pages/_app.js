__turbopack_load_page_chunks__("/_app", [
  "static/chunks/9e883_next_dist_compiled_712bffdb._.js",
  "static/chunks/9e883_next_dist_shared_lib_bc5614d9._.js",
  "static/chunks/9e883_next_dist_client_fe082e00._.js",
  "static/chunks/9e883_next_dist_4d2afce3._.js",
  "static/chunks/9e883_next_app_3f020608.js",
  "static/chunks/[next]_entry_page-loader_ts_c1675e40._.js",
  "static/chunks/9e883_react-dom_3d11c48e._.js",
  "static/chunks/9e883_bb6d2665._.js",
  "static/chunks/[root-of-the-server]__6a99bfdf._.js",
  "static/chunks/frontend_pages__app_2da965e7._.js",
  "static/chunks/turbopack-frontend_pages__app_53ccf651._.js"
])
