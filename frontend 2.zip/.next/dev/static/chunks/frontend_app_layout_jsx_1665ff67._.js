(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__06e3b2b9._.css",
  "static/chunks/9e883_ab6be4b9._.js",
  "static/chunks/frontend_app_e7b8774f._.js"
],
    source: "dynamic"
});
