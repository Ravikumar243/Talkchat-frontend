(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__b2a040c4._.css",
  "static/chunks/9e883_ab6be4b9._.js",
  "static/chunks/frontend_app_e0557700._.js"
],
    source: "dynamic"
});
