(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/9e883_ab6be4b9._.js",
  "static/chunks/frontend_app_50819023._.js"
],
    source: "dynamic"
});
