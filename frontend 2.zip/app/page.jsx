"use client";

import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchContact } from "./Redux/slice/ContactSlice";
import {sendMessage} from "./Redux/slice/sendMessageSlice"

const Page = () => {
  //   const [selectedContact, setSelectedContact] = useState(null);
  // const [messages, setMessages] = useState([]);
  // const [newMessage, setNewMessage] = useState("");


  // const dispatch = useDispatch();
  // const { contacts, loading, error } = useSelector((state) => state.contacts);
  // const {message} = useSelector((state)=> state.message);

  // console.log(contacts, "contact");

  // useEffect(() => {
  //   dispatch(fetchContact());
  // }, [dispatch]);

  // const handleSend=()=>{
  //    if (!newMessage.trim() || !selectedContact) return;

  //     const payload = {
  //     sender: "You",                
  //     receiver: selectedContact.id, 
  //     message: newMessage,
  //   };

  //   dispatch(sendMessage(payload))
    
  //   setMessages([...messages, { sender: "You", text: newMessage }]);
  //   setNewMessage("");
  // }





  return (
    // <div className="flex h-screen bg-gray-100">
    //   {/* LEFT SIDEBAR - Contact List */}
    //   <div className="w-1/3 bg-white border-r border-gray-300 p-4">
    //     <h2 className="text-xl font-bold mb-4 
       
    //     ">Contacts</h2>
    //     <ul>
    //       {contacts.map((contact) => (
    //         <li
    //           key={contact.id}
    //           onClick={() => setSelectedContact(contact)}
    //           // hover:bg-green-100
    //           className={`p-3 rounded-lg cursor-pointer  ${
    //             selectedContact?.id === contact.id ? "" : ""
    //           }`}
    //           // bg-green-200
    //         >
    //           <p className="font-semibold ">{contact.name}</p>
    //           <p className="text-sm">{contact.phone}</p>
    //         </li>
    //       ))}
    //     </ul>
    //   </div>

    //   {/* RIGHT SIDE - Chat Area */}
    //   <div className="flex-1 flex flex-col">
    //     {selectedContact ? (
    //       <>
    //         {/* Chat Header */}
            
    //         <div className="p-4 bg-green-500 font-semibold">
    //           Chat with {selectedContact.name}
    //         </div>

    //         {/* Chat Messages */}
    //         <div className="flex-1 p-4 overflow-y-auto bg-gray-50">
    //           {messages.length === 0 ? (
    //             <p className="text-gray-500 text-center mt-20">
    //               {/* No messages yet. */}
    //             </p>
    //           ) : (
    //             messages.map((msg, i) => (
    //               <div
    //                 key={i}
    //                 className={`mb-2 flex ${
    //                   msg.sender === "You" ? "justify-end" : "justify-start"
    //                 }`}
    //               >
    //                 <div
    //                   className={`p-2 rounded-lg ${
    //                     msg.sender === "You"
    //                       ? "bg-green-500 "
    //                       : "bg-gray-300"
    //                   }`}
    //                 >
    //                   {msg.text}
    //                 </div>
    //               </div>
    //             ))
    //           )}
    //         </div>

    //         {/* Message Input */}
    //         <div className="flex p-3 border-t border-gray-300">
    //           <input
    //             type="text"
    //             placeholder="Type your message..."
    //             value={newMessage}
    //             onChange={(e) => setNewMessage(e.target.value)}
    //             className="flex-1 p-2 border rounded-lg focus:outline-none"
    //           />
    //           <button
    //             onClick={handleSend}
                
    //             className="ml-2 px-4 py-2 bg-green-500 rounded-lg cursor-pointer"
    //           >
    //             Send
    //           </button>
    //         </div>
    //       </>
    //     ) : (
    //       <div className="flex items-center justify-center h-full text-gray-500">
    //         👈 Select a contact to start chatting
    //       </div>
    //     )}
    //   </div>
    // </div>
    <>
      helo
    </>
  );
};

export default Page;
