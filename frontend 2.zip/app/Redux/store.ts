import { configureStore } from "@reduxjs/toolkit";
import contactReducer from "./slice/ContactSlice";
import sendMessageReducer from "./slice/sendMessageSlice"

export const store = configureStore({
  reducer: {
    contacts: contactReducer,
    message : sendMessageReducer
  },
});
