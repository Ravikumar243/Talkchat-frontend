import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { BaseUrl } from "@/app/api/api";

// 🔹 Initial state
const initialState = {
  message: [],
  loading: false,
  error: null,
};

// 🔹 Example async thunk (optional: send message to backend)
export const sendMessage = createAsyncThunk(
  "message/sendMessage",
  async (newMessage, thunkAPI) => {
    try {
      const res = await fetch(`${BaseUrl}/sendMessages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newMessage),
      });

      const data = await res.json();
      return data; // expected response from backend
    } catch (err) {
      return thunkAPI.rejectWithValue(err.message);
    }
  }
);

// 🔹 Slice
const sendMessageSlice = createSlice({
  name: "message",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(sendMessage.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(sendMessage.fulfilled, (state, action) => {
        state.loading = false;
        state.message.push(action.payload);
      })
      .addCase(sendMessage.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export default sendMessageSlice.reducer;
