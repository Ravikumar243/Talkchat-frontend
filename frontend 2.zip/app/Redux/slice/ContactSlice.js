"use client";

import { BaseUrl } from "@/app/api/api";
import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

// 🔹 Initial State
const initialState = {
  contacts: [],
  loading: false,
  error: null,
};

// 🔹 Fetch all contacts
export const fetchContact = createAsyncThunk(
  "contacts/getContacts",
  async (_, thunkAPI) => {
    try {
      const res = await fetch(`${BaseUrl}/contacts`);
      const data = await res.json();
      return data.data;
    } catch (err) {
      return thunkAPI.rejectWithValue(err.message);
    }
  }
);

// 🔹 Create a new contact
export const createContact = createAsyncThunk(
  "contacts/createContact",
  async (newContact, thunkAPI) => {
    try {
      const res = await fetch(`${BaseUrl}/contacts`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newContact),
      });

      const data = await res.json();
      return data.data;
    } catch (err) {
      return thunkAPI.rejectWithValue(err.message);
    }
  }
);

// 🔹 Create Slice
const contactSlice = createSlice({
  name: "contacts",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      // ✅ Fetch contacts
      .addCase(fetchContact.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchContact.fulfilled, (state, action) => {
        state.loading = false;
        state.contacts = action.payload;
      })
      .addCase(fetchContact.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })

      // ✅ Create contact
      .addCase(createContact.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createContact.fulfilled, (state, action) => {
        state.loading = false;
        state.contacts.push(action.payload);
      })
      .addCase(createContact.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export default contactSlice.reducer;
